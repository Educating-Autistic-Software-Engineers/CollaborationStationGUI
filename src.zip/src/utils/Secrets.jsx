


export const secrets  = {
    ablyKey: "DrrD1w.YeN3qw:pgwl4ogJ8pnit8xe4qIQqoz83eB0dEFTGBT2KkSgvho",
    publicAccessKey: "AKIAWWEABKYFNTDN3ZVY",
    privateAccessKey: "zFfBaeGdId/AYFzXLNAEaj+jzgWmsjH82keTfR6T",
}