import AWS from 'aws-sdk';

// Configure the AWS SDK with your credentials and region
AWS.config.update({
  accessKeyId: "AKIAWWEABKYFNTDN3ZVY",
  secretAccessKey: "zFfBaeGdId/AYFzXLNAEaj+jzgWmsjH82keTfR6T",
  region: "us-east-2",
});

const s3 = new AWS.S3();

export default s3;