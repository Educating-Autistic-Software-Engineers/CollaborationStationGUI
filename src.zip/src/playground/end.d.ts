interface ImportMetaEnv {
    readonly VITE_ABLY_KEY: string;
  }